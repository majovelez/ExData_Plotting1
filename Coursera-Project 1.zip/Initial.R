##########Initial
install.packages("readr")
library(readr)
data <- read_delim("Coursera R/baselimpia.txt", ";", escape_double = FALSE, trim_ws = TRUE)
subset <- Date == "1/2/2007" | Date == "2/2/2007"
datapro <- data[subset, ]
attach(datapro)
x <- paste(Date, Time)
datapro$DateTime <- strptime(x, "%d/%m/%Y %H:%M:%S")
rownames(datapro) <- 1:nrow(datapro)

dim(datapro) 
attach(datapro)
getwd()
dir()
ls()
View(datapro)
names(datapro)
#[1] "Date"                  "Time"                  "Global_active_power"  
#[4] "Global_reactive_power" "Voltage"               "Global_intensity"     
#[7] "Sub_metering_1"        "Sub_metering_2"        "Sub_metering_3"